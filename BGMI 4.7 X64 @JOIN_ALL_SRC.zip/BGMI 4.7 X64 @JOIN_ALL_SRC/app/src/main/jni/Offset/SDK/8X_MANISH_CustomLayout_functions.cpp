// SDK GENERATE BY TELEGRAM ;- (@Manish8x) (4.7.0 -- 64Bit) DM TO BUY TOOL AVLABLE FOR SELL
// Telegram:- @Manish8x
// GEN ONWed Nov 18 07:25:37 2026
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------By Tg @Manish8x---------------------------
//Functions
//---------------------By Tg @Manish8x---------------------------

// Function CustomLayout.CustomizePanelBase.SetScale
// (Native, Public, BlueprintCallable)
// Parameters:
// float                          Scale                          (Parm, ZeroConstructor, IsPlainOldData)

void UCustomizePanelBase::SetScale(float Scale)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomizePanelBase.SetScale");

	UCustomizePanelBase_SetScale_Params params;
	params.Scale = Scale;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomizePanelBase.SetPosition
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// struct FVector2D               Position                       (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)

void UCustomizePanelBase::SetPosition(const struct FVector2D& Position)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomizePanelBase.SetPosition");

	UCustomizePanelBase_SetPosition_Params params;
	params.Position = Position;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomizePanelBase.SetOpacityWithClamp
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          InOpacity                      (Parm, ZeroConstructor, IsPlainOldData)
// float                          MinOpacity                     (Parm, ZeroConstructor, IsPlainOldData)
// float                          MaxOpacity                     (Parm, ZeroConstructor, IsPlainOldData)

void UCustomizePanelBase::SetOpacityWithClamp(float InOpacity, float MinOpacity, float MaxOpacity)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomizePanelBase.SetOpacityWithClamp");

	UCustomizePanelBase_SetOpacityWithClamp_Params params;
	params.InOpacity = InOpacity;
	params.MinOpacity = MinOpacity;
	params.MaxOpacity = MaxOpacity;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomizePanelBase.SetOpacity
// (Native, Public, BlueprintCallable)
// Parameters:
// float                          InOpacity                      (Parm, ZeroConstructor, IsPlainOldData)

void UCustomizePanelBase::SetOpacity(float InOpacity)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomizePanelBase.SetOpacity");

	UCustomizePanelBase_SetOpacity_Params params;
	params.InOpacity = InOpacity;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomizePanelBase.SetMovable
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bInMovable                     (Parm, ZeroConstructor, IsPlainOldData)

void UCustomizePanelBase::SetMovable(bool bInMovable)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomizePanelBase.SetMovable");

	UCustomizePanelBase_SetMovable_Params params;
	params.bInMovable = bInMovable;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomizePanelBase.SetMaxScale
// (Final, Native, Public, BlueprintCallable, Const)
// Parameters:
// float                          Scale                          (Parm, ZeroConstructor, IsPlainOldData)

void UCustomizePanelBase::SetMaxScale(float Scale)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomizePanelBase.SetMaxScale");

	UCustomizePanelBase_SetMaxScale_Params params;
	params.Scale = Scale;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomizePanelBase.SetInvalid
// (Native, Public, BlueprintCallable)
// Parameters:
// bool                           Invalid                        (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void UCustomizePanelBase::SetInvalid(bool Invalid)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomizePanelBase.SetInvalid");

	UCustomizePanelBase_SetInvalid_Params params;
	params.Invalid = Invalid;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomizePanelBase.SetInterceptChildInput
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bInIntercept                   (Parm, ZeroConstructor, IsPlainOldData)

void UCustomizePanelBase::SetInterceptChildInput(bool bInIntercept)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomizePanelBase.SetInterceptChildInput");

	UCustomizePanelBase_SetInterceptChildInput_Params params;
	params.bInIntercept = bInIntercept;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomizePanelBase.SetDrawMargin
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bDraw                          (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void UCustomizePanelBase::SetDrawMargin(bool bDraw)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomizePanelBase.SetDrawMargin");

	UCustomizePanelBase_SetDrawMargin_Params params;
	params.bDraw = bDraw;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomizePanelBase.SetDetectMargin
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FMargin                 InMargin                       (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)

void UCustomizePanelBase::SetDetectMargin(const struct FMargin& InMargin)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomizePanelBase.SetDetectMargin");

	UCustomizePanelBase_SetDetectMargin_Params params;
	params.InMargin = InMargin;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomizePanelBase.SetDesireScale
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          Scale                          (Parm, ZeroConstructor, IsPlainOldData)

void UCustomizePanelBase::SetDesireScale(float Scale)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomizePanelBase.SetDesireScale");

	UCustomizePanelBase_SetDesireScale_Params params;
	params.Scale = Scale;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomizePanelBase.SetDesirePosition
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// struct FVector2D               Position                       (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)

void UCustomizePanelBase::SetDesirePosition(const struct FVector2D& Position)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomizePanelBase.SetDesirePosition");

	UCustomizePanelBase_SetDesirePosition_Params params;
	params.Position = Position;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomizePanelBase.SetDefaultLayoutCode
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FCustomLayoutBlueprintCode InCode                         (ConstParm, Parm, OutParm, ReferenceParm)

void UCustomizePanelBase::SetDefaultLayoutCode(const struct FCustomLayoutBlueprintCode& InCode)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomizePanelBase.SetDefaultLayoutCode");

	UCustomizePanelBase_SetDefaultLayoutCode_Params params;
	params.InCode = InCode;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomizePanelBase.SetDefaultLayoutByPositionAndAnchors
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// struct FVector2D               InPosition                     (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
// struct FAnchors                InAnchors                      (ConstParm, Parm, OutParm, ReferenceParm)

void UCustomizePanelBase::SetDefaultLayoutByPositionAndAnchors(const struct FVector2D& InPosition, const struct FAnchors& InAnchors)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomizePanelBase.SetDefaultLayoutByPositionAndAnchors");

	UCustomizePanelBase_SetDefaultLayoutByPositionAndAnchors_Params params;
	params.InPosition = InPosition;
	params.InAnchors = InAnchors;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomizePanelBase.SetCustomType
// (Native, Public, BlueprintCallable)
// Parameters:
// int                            NewType                        (Parm, ZeroConstructor, IsPlainOldData)

void UCustomizePanelBase::SetCustomType(int NewType)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomizePanelBase.SetCustomType");

	UCustomizePanelBase_SetCustomType_Params params;
	params.NewType = NewType;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomizePanelBase.RestoreInBound
// (Final, Native, Public, BlueprintCallable, Const)

void UCustomizePanelBase::RestoreInBound()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomizePanelBase.RestoreInBound");

	UCustomizePanelBase_RestoreInBound_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomizePanelBase.ResetMaxScale
// (Final, Native, Public, BlueprintCallable, Const)

void UCustomizePanelBase::ResetMaxScale()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomizePanelBase.ResetMaxScale");

	UCustomizePanelBase_ResetMaxScale_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomizePanelBase.IsOutOfBound
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          InvisibleCheckOffset           (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UCustomizePanelBase::IsOutOfBound(float InvisibleCheckOffset)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomizePanelBase.IsOutOfBound");

	UCustomizePanelBase_IsOutOfBound_Params params;
	params.InvisibleCheckOffset = InvisibleCheckOffset;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.CustomizePanelBase.InitDefaultLayoutData
// (Final, Native, Public, BlueprintCallable)

void UCustomizePanelBase::InitDefaultLayoutData()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomizePanelBase.InitDefaultLayoutData");

	UCustomizePanelBase_InitDefaultLayoutData_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomizePanelBase.GetScale
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float UCustomizePanelBase::GetScale()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomizePanelBase.GetScale");

	UCustomizePanelBase_GetScale_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.CustomizePanelBase.GetPosition
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FVector2D               ReturnValue                    (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FVector2D UCustomizePanelBase::GetPosition()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomizePanelBase.GetPosition");

	UCustomizePanelBase_GetPosition_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.CustomizePanelBase.GetOpacity
// (Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float UCustomizePanelBase::GetOpacity()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomizePanelBase.GetOpacity");

	UCustomizePanelBase_GetOpacity_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.CustomizePanelBase.GetMovable
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UCustomizePanelBase::GetMovable()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomizePanelBase.GetMovable");

	UCustomizePanelBase_GetMovable_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.CustomizePanelBase.GetMaxScale
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float UCustomizePanelBase::GetMaxScale()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomizePanelBase.GetMaxScale");

	UCustomizePanelBase_GetMaxScale_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.CustomizePanelBase.GetLayoutData
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FUIElemLayoutDetail     ReturnValue                    (Parm, OutParm, ReturnParm)

struct FUIElemLayoutDetail UCustomizePanelBase::GetLayoutData()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomizePanelBase.GetLayoutData");

	UCustomizePanelBase_GetLayoutData_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.CustomizePanelBase.GetLayoutCode
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FCustomLayoutBlueprintCode ReturnValue                    (Parm, OutParm, ReturnParm)

struct FCustomLayoutBlueprintCode UCustomizePanelBase::GetLayoutCode()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomizePanelBase.GetLayoutCode");

	UCustomizePanelBase_GetLayoutCode_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.CustomizePanelBase.GetInvalid
// (Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UCustomizePanelBase::GetInvalid()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomizePanelBase.GetInvalid");

	UCustomizePanelBase_GetInvalid_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.CustomizePanelBase.GetDefaultLayoutData
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FUIElemLayoutDetail     ReturnValue                    (Parm, OutParm, ReturnParm)

struct FUIElemLayoutDetail UCustomizePanelBase::GetDefaultLayoutData()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomizePanelBase.GetDefaultLayoutData");

	UCustomizePanelBase_GetDefaultLayoutData_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.CustomizePanelBase.GetCustomType
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UCustomizePanelBase::GetCustomType()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomizePanelBase.GetCustomType");

	UCustomizePanelBase_GetCustomType_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.CustomizePanelBase.ClampPosition
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FVector2D               DesiredPos                     (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
// struct FVector2D               ReturnValue                    (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FVector2D UCustomizePanelBase::ClampPosition(const struct FVector2D& DesiredPos)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomizePanelBase.ClampPosition");

	UCustomizePanelBase_ClampPosition_Params params;
	params.DesiredPos = DesiredPos;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.CustomizePanelBase.ApplyLayoutData
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FUIElemLayoutDetail     LayoutDetail                   (ConstParm, Parm, OutParm, ReferenceParm)

void UCustomizePanelBase::ApplyLayoutData(const struct FUIElemLayoutDetail& LayoutDetail)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomizePanelBase.ApplyLayoutData");

	UCustomizePanelBase_ApplyLayoutData_Params params;
	params.LayoutDetail = LayoutDetail;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomizePanelBase.ApplyLayoutCode
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FCustomLayoutBlueprintCode InCode                         (ConstParm, Parm, OutParm, ReferenceParm)

void UCustomizePanelBase::ApplyLayoutCode(const struct FCustomLayoutBlueprintCode& InCode)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomizePanelBase.ApplyLayoutCode");

	UCustomizePanelBase_ApplyLayoutCode_Params params;
	params.InCode = InCode;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomizePanelBase.ApplyDefaultLayout
// (Final, Native, Public, BlueprintCallable)

void UCustomizePanelBase::ApplyDefaultLayout()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomizePanelBase.ApplyDefaultLayout");

	UCustomizePanelBase_ApplyDefaultLayout_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomLayoutBlueprintLibrary.MakeLayoutDetail
// (Final, Native, Static, Public, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// int                            Type                           (Parm, ZeroConstructor, IsPlainOldData)
// EAnchorsType                   AnchorType                     (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector2D               Offset                         (Parm, IsPlainOldData)
// struct FUIElemLayoutDetail     ReturnValue                    (Parm, OutParm, ReturnParm)

struct FUIElemLayoutDetail UCustomLayoutBlueprintLibrary::MakeLayoutDetail(int Type, EAnchorsType AnchorType, const struct FVector2D& Offset)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomLayoutBlueprintLibrary.MakeLayoutDetail");

	UCustomLayoutBlueprintLibrary_MakeLayoutDetail_Params params;
	params.Type = Type;
	params.AnchorType = AnchorType;
	params.Offset = Offset;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.CustomLayoutBlueprintLibrary.GenerateUserSettingFromIndexer
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class UDynamicCustomIndexer*   InIndexer                      (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// class UCustomLayoutUserSetting* InOutUserSetting               (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UCustomLayoutBlueprintLibrary::GenerateUserSettingFromIndexer(class UDynamicCustomIndexer* InIndexer, class UCustomLayoutUserSetting* InOutUserSetting)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomLayoutBlueprintLibrary.GenerateUserSettingFromIndexer");

	UCustomLayoutBlueprintLibrary_GenerateUserSettingFromIndexer_Params params;
	params.InIndexer = InIndexer;
	params.InOutUserSetting = InOutUserSetting;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.CustomLayoutBlueprintLibrary.CreateCustomLayoutUserSetting
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// struct FString                 InSaveSlotName                 (Parm, ZeroConstructor)
// class UCustomLayoutUserSetting* ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UCustomLayoutUserSetting* UCustomLayoutBlueprintLibrary::CreateCustomLayoutUserSetting(const struct FString& InSaveSlotName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomLayoutBlueprintLibrary.CreateCustomLayoutUserSetting");

	UCustomLayoutBlueprintLibrary_CreateCustomLayoutUserSetting_Params params;
	params.InSaveSlotName = InSaveSlotName;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.CustomLayoutBlueprintLibrary.Conv_TypeToAnchors
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// EAnchorsType                   InType                         (Parm, ZeroConstructor, IsPlainOldData)
// struct FAnchors                ReturnValue                    (Parm, OutParm, ReturnParm)

struct FAnchors UCustomLayoutBlueprintLibrary::Conv_TypeToAnchors(EAnchorsType InType)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomLayoutBlueprintLibrary.Conv_TypeToAnchors");

	UCustomLayoutBlueprintLibrary_Conv_TypeToAnchors_Params params;
	params.InType = InType;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.CustomLayoutBlueprintLibrary.Conv_TouchStatInfoToLong
// (Final, Native, Static, Public, HasOutParms)
// Parameters:
// struct FTouchStatInfo          Info                           (ConstParm, Parm, OutParm, ReferenceParm)
// uint64_t                       ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

uint64_t UCustomLayoutBlueprintLibrary::Conv_TouchStatInfoToLong(const struct FTouchStatInfo& Info)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomLayoutBlueprintLibrary.Conv_TouchStatInfoToLong");

	UCustomLayoutBlueprintLibrary_Conv_TouchStatInfoToLong_Params params;
	params.Info = Info;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.CustomLayoutBlueprintLibrary.Conv_LongToTouchStatInfo
// (Final, Native, Static, Public, HasOutParms)
// Parameters:
// uint64_t                       Num                            (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
// struct FTouchStatInfo          ReturnValue                    (Parm, OutParm, ReturnParm)

struct FTouchStatInfo UCustomLayoutBlueprintLibrary::Conv_LongToTouchStatInfo(uint64_t Num)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomLayoutBlueprintLibrary.Conv_LongToTouchStatInfo");

	UCustomLayoutBlueprintLibrary_Conv_LongToTouchStatInfo_Params params;
	params.Num = Num;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.CustomLayoutBlueprintLibrary.Conv_LayoutDetailToCode
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FUIElemLayoutDetail     InDetail                       (ConstParm, Parm, OutParm, ReferenceParm)
// struct FCustomLayoutBlueprintCode ReturnValue                    (Parm, OutParm, ReturnParm)

struct FCustomLayoutBlueprintCode UCustomLayoutBlueprintLibrary::Conv_LayoutDetailToCode(const struct FUIElemLayoutDetail& InDetail)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomLayoutBlueprintLibrary.Conv_LayoutDetailToCode");

	UCustomLayoutBlueprintLibrary_Conv_LayoutDetailToCode_Params params;
	params.InDetail = InDetail;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.CustomLayoutBlueprintLibrary.Conv_CodeToLayoutDetail
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FCustomLayoutBlueprintCode InCode                         (ConstParm, Parm, OutParm, ReferenceParm)
// int                            Type                           (Parm, ZeroConstructor, IsPlainOldData)
// struct FUIElemLayoutDetail     ReturnValue                    (Parm, OutParm, ReturnParm)

struct FUIElemLayoutDetail UCustomLayoutBlueprintLibrary::Conv_CodeToLayoutDetail(const struct FCustomLayoutBlueprintCode& InCode, int Type)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomLayoutBlueprintLibrary.Conv_CodeToLayoutDetail");

	UCustomLayoutBlueprintLibrary_Conv_CodeToLayoutDetail_Params params;
	params.InCode = InCode;
	params.Type = Type;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.CustomLayoutBlueprintLibrary.Conv_AnchorsToType
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable, BlueprintPure)
// Parameters:
// struct FAnchors                InAnchors                      (ConstParm, Parm, OutParm, ReferenceParm)
// EAnchorsType                   ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EAnchorsType UCustomLayoutBlueprintLibrary::Conv_AnchorsToType(const struct FAnchors& InAnchors)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomLayoutBlueprintLibrary.Conv_AnchorsToType");

	UCustomLayoutBlueprintLibrary_Conv_AnchorsToType_Params params;
	params.InAnchors = InAnchors;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.CustomLayoutSubsystem.UnregisterCustomPanel
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class UCustomPanel*            InCustomizePanel               (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)

void UCustomLayoutSubsystem::UnregisterCustomPanel(class UCustomPanel* InCustomizePanel)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomLayoutSubsystem.UnregisterCustomPanel");

	UCustomLayoutSubsystem_UnregisterCustomPanel_Params params;
	params.InCustomizePanel = InCustomizePanel;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomLayoutSubsystem.SetScreenPadding
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FMargin                 InOffset                       (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)

void UCustomLayoutSubsystem::SetScreenPadding(const struct FMargin& InOffset)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomLayoutSubsystem.SetScreenPadding");

	UCustomLayoutSubsystem_SetScreenPadding_Params params;
	params.InOffset = InOffset;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomLayoutSubsystem.SetEditMode
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bEnable                        (Parm, ZeroConstructor, IsPlainOldData)

void UCustomLayoutSubsystem::SetEditMode(bool bEnable)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomLayoutSubsystem.SetEditMode");

	UCustomLayoutSubsystem_SetEditMode_Params params;
	params.bEnable = bEnable;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomLayoutSubsystem.RemoveUserSettingSlot
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class UCustomLayoutUserSetting* InUserSetting                  (Parm, ZeroConstructor, IsPlainOldData)

void UCustomLayoutSubsystem::RemoveUserSettingSlot(class UCustomLayoutUserSetting* InUserSetting)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomLayoutSubsystem.RemoveUserSettingSlot");

	UCustomLayoutSubsystem_RemoveUserSettingSlot_Params params;
	params.InUserSetting = InUserSetting;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomLayoutSubsystem.RegisterCustomPanel
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class UCustomPanel*            InCustomizePanel               (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)

void UCustomLayoutSubsystem::RegisterCustomPanel(class UCustomPanel* InCustomizePanel)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomLayoutSubsystem.RegisterCustomPanel");

	UCustomLayoutSubsystem_RegisterCustomPanel_Params params;
	params.InCustomizePanel = InCustomizePanel;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomLayoutSubsystem.InsertUserSettingSlot
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class UCustomLayoutUserSetting* InUserSetting                  (Parm, ZeroConstructor, IsPlainOldData)
// int                            Index                          (Parm, ZeroConstructor, IsPlainOldData)

void UCustomLayoutSubsystem::InsertUserSettingSlot(class UCustomLayoutUserSetting* InUserSetting, int Index)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomLayoutSubsystem.InsertUserSettingSlot");

	UCustomLayoutSubsystem_InsertUserSettingSlot_Params params;
	params.InUserSetting = InUserSetting;
	params.Index = Index;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomLayoutSubsystem.GetUserSettingInSlot
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FString                 Name                           (Parm, ZeroConstructor)
// class UCustomLayoutUserSetting* ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UCustomLayoutUserSetting* UCustomLayoutSubsystem::GetUserSettingInSlot(const struct FString& Name)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomLayoutSubsystem.GetUserSettingInSlot");

	UCustomLayoutSubsystem_GetUserSettingInSlot_Params params;
	params.Name = Name;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.CustomLayoutSubsystem.GetRegisteredPanel
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// int                            InCustomType                   (Parm, ZeroConstructor, IsPlainOldData)
// class UCustomPanel*            ReturnValue                    (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)

class UCustomPanel* UCustomLayoutSubsystem::GetRegisteredPanel(int InCustomType)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomLayoutSubsystem.GetRegisteredPanel");

	UCustomLayoutSubsystem_GetRegisteredPanel_Params params;
	params.InCustomType = InCustomType;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.CustomLayoutSubsystem.FlushRegisteredPanelMap
// (Final, Native, Public, BlueprintCallable)

void UCustomLayoutSubsystem::FlushRegisteredPanelMap()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomLayoutSubsystem.FlushRegisteredPanelMap");

	UCustomLayoutSubsystem_FlushRegisteredPanelMap_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomLayoutSubsystem.FindLayoutDetail
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            InCustomType                   (Parm, ZeroConstructor, IsPlainOldData)
// struct FUIElemLayoutDetail     OutDetail                      (Parm, OutParm)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UCustomLayoutSubsystem::FindLayoutDetail(int InCustomType, struct FUIElemLayoutDetail* OutDetail)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomLayoutSubsystem.FindLayoutDetail");

	UCustomLayoutSubsystem_FindLayoutDetail_Params params;
	params.InCustomType = InCustomType;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (OutDetail != nullptr)
		*OutDetail = params.OutDetail;

	return params.ReturnValue;
}


// Function CustomLayout.CustomLayoutSubsystem.ClearUserSettingSlots
// (Final, Native, Public, BlueprintCallable)

void UCustomLayoutSubsystem::ClearUserSettingSlots()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomLayoutSubsystem.ClearUserSettingSlots");

	UCustomLayoutSubsystem_ClearUserSettingSlots_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomLayoutSubsystem.ClearRegisteredPanelMap
// (Final, Native, Public, BlueprintCallable)

void UCustomLayoutSubsystem::ClearRegisteredPanelMap()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomLayoutSubsystem.ClearRegisteredPanelMap");

	UCustomLayoutSubsystem_ClearRegisteredPanelMap_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomLayoutSubsystem.BroadcastCustomLayoutChange
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// TArray<int>                    InCustomTypeList               (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void UCustomLayoutSubsystem::BroadcastCustomLayoutChange(TArray<int> InCustomTypeList)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomLayoutSubsystem.BroadcastCustomLayoutChange");

	UCustomLayoutSubsystem_BroadcastCustomLayoutChange_Params params;
	params.InCustomTypeList = InCustomTypeList;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomLayoutSubsystem.AddUserSettingSlot
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class UCustomLayoutUserSetting* InUserSetting                  (Parm, ZeroConstructor, IsPlainOldData)

void UCustomLayoutSubsystem::AddUserSettingSlot(class UCustomLayoutUserSetting* InUserSetting)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomLayoutSubsystem.AddUserSettingSlot");

	UCustomLayoutSubsystem_AddUserSettingSlot_Params params;
	params.InUserSetting = InUserSetting;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomLayoutUserSetting.UpdateTimeTag
// (Final, Native, Public, BlueprintCallable)

void UCustomLayoutUserSetting::UpdateTimeTag()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomLayoutUserSetting.UpdateTimeTag");

	UCustomLayoutUserSetting_UpdateTimeTag_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomLayoutUserSetting.SetTimeTagFromUnixTimestamp
// (Final, Native, Public)
// Parameters:
// int64_t                        InUnixTimestamp                (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void UCustomLayoutUserSetting::SetTimeTagFromUnixTimestamp(int64_t InUnixTimestamp)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomLayoutUserSetting.SetTimeTagFromUnixTimestamp");

	UCustomLayoutUserSetting_SetTimeTagFromUnixTimestamp_Params params;
	params.InUnixTimestamp = InUnixTimestamp;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomLayoutUserSetting.SetDataByLayoutDetail
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// int                            InCustomType                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FUIElemLayoutDetail     InData                         (ConstParm, Parm, OutParm, ReferenceParm)

void UCustomLayoutUserSetting::SetDataByLayoutDetail(int InCustomType, const struct FUIElemLayoutDetail& InData)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomLayoutUserSetting.SetDataByLayoutDetail");

	UCustomLayoutUserSetting_SetDataByLayoutDetail_Params params;
	params.InCustomType = InCustomType;
	params.InData = InData;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomLayoutUserSetting.RemoveData
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// int                            InCustomType                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void UCustomLayoutUserSetting::RemoveData(int InCustomType)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomLayoutUserSetting.RemoveData");

	UCustomLayoutUserSetting_RemoveData_Params params;
	params.InCustomType = InCustomType;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomLayoutUserSetting.GetTimeTagAsUnixTimestamp
// (Final, Native, Public, Const)
// Parameters:
// int64_t                        ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int64_t UCustomLayoutUserSetting::GetTimeTagAsUnixTimestamp()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomLayoutUserSetting.GetTimeTagAsUnixTimestamp");

	UCustomLayoutUserSetting_GetTimeTagAsUnixTimestamp_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.CustomLayoutUserSetting.GetLayoutCodeCheckSum
// (Final, Native, Public, Const)
// Parameters:
// uint64_t                       ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

uint64_t UCustomLayoutUserSetting::GetLayoutCodeCheckSum()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomLayoutUserSetting.GetLayoutCodeCheckSum");

	UCustomLayoutUserSetting_GetLayoutCodeCheckSum_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.CustomLayoutUserSetting.GetDataAsLayoutDetail
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            InCustomType                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// struct FUIElemLayoutDetail     ReturnValue                    (Parm, OutParm, ReturnParm)

struct FUIElemLayoutDetail UCustomLayoutUserSetting::GetDataAsLayoutDetail(int InCustomType)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomLayoutUserSetting.GetDataAsLayoutDetail");

	UCustomLayoutUserSetting_GetDataAsLayoutDetail_Params params;
	params.InCustomType = InCustomType;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.CustomLayoutUserSetting.GetCustomTypeList
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TArray<int>                    OutKeys                        (Parm, OutParm, ZeroConstructor)

void UCustomLayoutUserSetting::GetCustomTypeList(TArray<int>* OutKeys)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomLayoutUserSetting.GetCustomTypeList");

	UCustomLayoutUserSetting_GetCustomTypeList_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (OutKeys != nullptr)
		*OutKeys = params.OutKeys;
}


// Function CustomLayout.CustomLayoutUserSetting.Contains
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            InCustomType                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UCustomLayoutUserSetting::Contains(int InCustomType)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomLayoutUserSetting.Contains");

	UCustomLayoutUserSetting_Contains_Params params;
	params.InCustomType = InCustomType;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.CustomPanel.UpdateCustomLayout
// (Final, Native, Public, BlueprintCallable)

void UCustomPanel::UpdateCustomLayout()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomPanel.UpdateCustomLayout");

	UCustomPanel_UpdateCustomLayout_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.CustomPanel.SetEditable
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bEditable                      (Parm, ZeroConstructor, IsPlainOldData)

void UCustomPanel::SetEditable(bool bEditable)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.CustomPanel.SetEditable");

	UCustomPanel_SetEditable_Params params;
	params.bEditable = bEditable;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.DynamicCustomIndexer.SetupDefaultLayoutForPanel
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            CustomType                     (Parm, ZeroConstructor, IsPlainOldData)
// class UCustomizePanelBase*     Panel                          (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UDynamicCustomIndexer::SetupDefaultLayoutForPanel(int CustomType, class UCustomizePanelBase* Panel)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.DynamicCustomIndexer.SetupDefaultLayoutForPanel");

	UDynamicCustomIndexer_SetupDefaultLayoutForPanel_Params params;
	params.CustomType = CustomType;
	params.Panel = Panel;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.DynamicCustomIndexer.GetIndexer
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// struct FString                 Path                           (Parm, ZeroConstructor)
// class UDynamicCustomIndexer*   ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UDynamicCustomIndexer* UDynamicCustomIndexer::GetIndexer(const struct FString& Path)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.DynamicCustomIndexer.GetIndexer");

	UDynamicCustomIndexer_GetIndexer_Params params;
	params.Path = Path;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.DynamicCustomIndexer.CreateDynamicCustomWidgets
// (Final, Native, Public, HasOutParms)
// Parameters:
// TArray<int>                    InCustomTypeList               (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// TMap<int, class UCustomizePanelBase*> CustomPanelMap                 (Parm, OutParm, ZeroConstructor)
// class UPanelWidget*            Container                      (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
// bool                           bIgnoreDPIScale                (Parm, ZeroConstructor, IsPlainOldData)
// TMap<int, class UCustomizePanelBase*> ReturnValue                    (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm)

TMap<int, class UCustomizePanelBase*> UDynamicCustomIndexer::CreateDynamicCustomWidgets(TArray<int> InCustomTypeList, class UPanelWidget* Container, bool bIgnoreDPIScale, TMap<int, class UCustomizePanelBase*>* CustomPanelMap)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.DynamicCustomIndexer.CreateDynamicCustomWidgets");

	UDynamicCustomIndexer_CreateDynamicCustomWidgets_Params params;
	params.InCustomTypeList = InCustomTypeList;
	params.Container = Container;
	params.bIgnoreDPIScale = bIgnoreDPIScale;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (CustomPanelMap != nullptr)
		*CustomPanelMap = params.CustomPanelMap;

	return params.ReturnValue;
}


// Function CustomLayout.PinchDragWidget.SetPinchEnabled
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bEnabled                       (Parm, ZeroConstructor, IsPlainOldData)

void UPinchDragWidget::SetPinchEnabled(bool bEnabled)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.PinchDragWidget.SetPinchEnabled");

	UPinchDragWidget_SetPinchEnabled_Params params;
	params.bEnabled = bEnabled;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.PinchDragWidget.SetDragEnabled
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bEnabled                       (Parm, ZeroConstructor, IsPlainOldData)

void UPinchDragWidget::SetDragEnabled(bool bEnabled)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.PinchDragWidget.SetDragEnabled");

	UPinchDragWidget_SetDragEnabled_Params params;
	params.bEnabled = bEnabled;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.PinchDragWidget.ScreenDeltaToParentLocal
// (Final, Native, Static, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure)
// Parameters:
// class UWidget*                 Widget                         (ConstParm, Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
// struct FVector2D               ScreenDelta                    (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
// struct FVector2D               ReturnValue                    (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FVector2D UPinchDragWidget::ScreenDeltaToParentLocal(class UWidget* Widget, const struct FVector2D& ScreenDelta)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.PinchDragWidget.ScreenDeltaToParentLocal");

	UPinchDragWidget_ScreenDeltaToParentLocal_Params params;
	params.Widget = Widget;
	params.ScreenDelta = ScreenDelta;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.PinchDragWidget.Reset
// (Final, Native, Public, BlueprintCallable)

void UPinchDragWidget::Reset()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.PinchDragWidget.Reset");

	UPinchDragWidget_Reset_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.PinchDragWidget.IsPinchEnabled
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UPinchDragWidget::IsPinchEnabled()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.PinchDragWidget.IsPinchEnabled");

	UPinchDragWidget_IsPinchEnabled_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.PinchDragWidget.IsFirstPointIndex
// (Final, Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FPointerEvent           InPointerEvent                 (ConstParm, Parm, OutParm, ReferenceParm)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UPinchDragWidget::IsFirstPointIndex(const struct FPointerEvent& InPointerEvent)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.PinchDragWidget.IsFirstPointIndex");

	UPinchDragWidget_IsFirstPointIndex_Params params;
	params.InPointerEvent = InPointerEvent;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.PinchDragWidget.IsDragEnabled
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UPinchDragWidget::IsDragEnabled()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.PinchDragWidget.IsDragEnabled");

	UPinchDragWidget_IsDragEnabled_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.SettingCustomPanel.SetSelectedImageOriginEffect
// (Final, Native, Public, BlueprintCallable)

void USettingCustomPanel::SetSelectedImageOriginEffect()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.SettingCustomPanel.SetSelectedImageOriginEffect");

	USettingCustomPanel_SetSelectedImageOriginEffect_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.SettingCustomPanel.SetSelectedImageFlashEffect
// (Final, Native, Public, BlueprintCallable)

void USettingCustomPanel::SetSelectedImageFlashEffect()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.SettingCustomPanel.SetSelectedImageFlashEffect");

	USettingCustomPanel_SetSelectedImageFlashEffect_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.SettingCustomPanel.SetDisplayState
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// ESCPDisplayState               State                          (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void USettingCustomPanel::SetDisplayState(ESCPDisplayState State)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.SettingCustomPanel.SetDisplayState");

	USettingCustomPanel_SetDisplayState_Params params;
	params.State = State;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.SettingCustomPanel.OnTouchPreview
// (Event, Protected, BlueprintEvent)

void USettingCustomPanel::OnTouchPreview()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.SettingCustomPanel.OnTouchPreview");

	USettingCustomPanel_OnTouchPreview_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.SettingCustomPanel.IsSquareFlashEffectAssetName
// (Event, Public, BlueprintEvent)
// Parameters:
// struct FString                 InAssetName                    (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool USettingCustomPanel::IsSquareFlashEffectAssetName(const struct FString& InAssetName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.SettingCustomPanel.IsSquareFlashEffectAssetName");

	USettingCustomPanel_IsSquareFlashEffectAssetName_Params params;
	params.InAssetName = InAssetName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.SettingCustomPanel.IsCircleFlashEffectAssetName
// (Event, Public, BlueprintEvent)
// Parameters:
// struct FString                 InAssetName                    (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool USettingCustomPanel::IsCircleFlashEffectAssetName(const struct FString& InAssetName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.SettingCustomPanel.IsCircleFlashEffectAssetName");

	USettingCustomPanel_IsCircleFlashEffectAssetName_Params params;
	params.InAssetName = InAssetName;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.SettingCustomPanel.GetWidgetByType
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class UWidget*                 RootWidget                     (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
// class UClass*                  WidgetType                     (Parm, ZeroConstructor, IsPlainOldData)
// class UWidget*                 ReturnValue                    (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)

class UWidget* USettingCustomPanel::GetWidgetByType(class UWidget* RootWidget, class UClass* WidgetType)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.SettingCustomPanel.GetWidgetByType");

	USettingCustomPanel_GetWidgetByType_Params params;
	params.RootWidget = RootWidget;
	params.WidgetType = WidgetType;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.SettingCustomPanel.GetSelectedImage
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class UImage*                  ReturnValue                    (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)

class UImage* USettingCustomPanel::GetSelectedImage()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.SettingCustomPanel.GetSelectedImage");

	USettingCustomPanel_GetSelectedImage_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.SettingCustomPanel.GetParentWidget
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class UWidget*                 ReturnValue                    (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)

class UWidget* USettingCustomPanel::GetParentWidget()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.SettingCustomPanel.GetParentWidget");

	USettingCustomPanel_GetParentWidget_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.SettingCustomPanel.GetNamedWidgetFromOwner
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FString                 Prefix                         (Parm, ZeroConstructor)
// class UWidget*                 ReturnValue                    (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)

class UWidget* USettingCustomPanel::GetNamedWidgetFromOwner(const struct FString& Prefix)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.SettingCustomPanel.GetNamedWidgetFromOwner");

	USettingCustomPanel_GetNamedWidgetFromOwner_Params params;
	params.Prefix = Prefix;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.SettingCustomPanel.GetInvalidImage
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class UImage*                  ReturnValue                    (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)

class UImage* USettingCustomPanel::GetInvalidImage()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.SettingCustomPanel.GetInvalidImage");

	USettingCustomPanel_GetInvalidImage_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.SettingCustomPanel.GetCenterPositionInScreenSpace
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// class UWidget*                 FullScreenWidget               (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
// struct FVector2D               ReturnValue                    (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FVector2D USettingCustomPanel::GetCenterPositionInScreenSpace(class UWidget* FullScreenWidget)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.SettingCustomPanel.GetCenterPositionInScreenSpace");

	USettingCustomPanel_GetCenterPositionInScreenSpace_Params params;
	params.FullScreenWidget = FullScreenWidget;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function CustomLayout.SettingCustomPanel.FlashHighlight
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          Seconds                        (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void USettingCustomPanel::FlashHighlight(float Seconds)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.SettingCustomPanel.FlashHighlight");

	USettingCustomPanel_FlashHighlight_Params params;
	params.Seconds = Seconds;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function CustomLayout.SettingCustomPanel.ConvertCenterPositionFromScreenSpace
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// class UWidget*                 FullScreenWidget               (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
// struct FVector2D               SSPosition                     (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
// struct FVector2D               ReturnValue                    (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FVector2D USettingCustomPanel::ConvertCenterPositionFromScreenSpace(class UWidget* FullScreenWidget, const struct FVector2D& SSPosition)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function CustomLayout.SettingCustomPanel.ConvertCenterPositionFromScreenSpace");

	USettingCustomPanel_ConvertCenterPositionFromScreenSpace_Params params;
	params.FullScreenWidget = FullScreenWidget;
	params.SSPosition = SSPosition;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


}

