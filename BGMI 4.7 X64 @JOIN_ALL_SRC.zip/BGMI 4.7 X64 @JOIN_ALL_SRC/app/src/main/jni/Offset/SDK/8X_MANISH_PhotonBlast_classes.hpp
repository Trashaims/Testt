#pragma once

// SDK GENERATE BY TELEGRAM ;- (@Manish8x) (4.7.0 -- 64Bit) DM TO BUY TOOL AVLABLE FOR SELL
// Telegram:- @Manish8x
// GEN ONWed Nov 18 07:25:35 2026
 
namespace SDK
{
//---------------------By Tg @Manish8x---------------------------
//Classes
//---------------------By Tg @Manish8x---------------------------

// Class PhotonBlast.PhotonReplicationStaticMeshComponent
// 0x00E0 (0x0CC0 - 0x0BE0)
class UPhotonReplicationStaticMeshComponent : public UStaticMeshComponent
{
public:
	unsigned char                                      UnknownData00[0x58];                                      // 0x0BE0(0x0058) MISSED OFFSET
	int                                                ClusterUniqueID;                                          // 0x0C38(0x0004) (Edit, ZeroConstructor, DisableEditOnTemplate, EditConst, IsPlainOldData)
	bool                                               bCanMove;                                                 // 0x0C3C(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	EAOIEntityType                                     AOIEntityType;                                            // 0x0C3D(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	EClusterEntityState                                AOIEntityState;                                           // 0x0C3E(0x0001) (Edit, ZeroConstructor, DisableEditOnTemplate, EditConst, IsPlainOldData)
	unsigned char                                      ClusterReplicationOpen : 1;                               // 0x0C3F(0x0001) (Edit, BlueprintVisible)
	class UDestructionSubsystem*                       SubsystemPtr;                                             // 0x0C40(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0C48(0x0008) MISSED OFFSET
	struct FLuaNetSerialization                        LuaNetSerialization;                                      // 0x0C50(0x0050) (Net)
	struct FString                                     LuaFilePath;                                              // 0x0CA0(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	unsigned char                                      UnknownData02[0x10];                                      // 0x0CB0(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PhotonBlast.PhotonReplicationStaticMeshComponent");
		return pStaticClass;
	}


	void UnRegistLuaTick();
	void UnRegisterFromCluster();
	void SetMoveable(bool Value);
	void SetClusterUniqueID(int InClusterID);
	void SetClusterEntityState(EClusterEntityState EntityState);
	void RegistLuaTick(float TickInterval);
	void RegisterToCluster();
	void MarkPropDirty(int PropIndex);
};


// Class PhotonBlast.PhotonDestructibleMeshComponent
// 0x0290 (0x0F50 - 0x0CC0)
class UPhotonDestructibleMeshComponent : public UPhotonReplicationStaticMeshComponent
{
public:
	unsigned char                                      EnableImpactDamage : 1;                                   // 0x0CC0(0x0001) (Edit)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0CC1(0x0003) MISSED OFFSET
	struct FPhotonDestructibleImpactParam              ImpactParam;                                              // 0x0CC4(0x0008) (Edit)
	unsigned char                                      SynchronizeChunkData : 1;                                 // 0x0CCC(0x0001) (Edit)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0CCD(0x0003) MISSED OFFSET
	class UPhotonDestructibleMesh*                     PhotonDestructibleMesh;                                   // 0x0CD0(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ECollisionEnabled>                FragmentsCollisionEnabled;                                // 0x0CD8(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x7];                                       // 0x0CD9(0x0007) MISSED OFFSET
	struct FName                                       FragmentsCollisionProfileName;                            // 0x0CE0(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      InitialVisible : 1;                                       // 0x0CE8(0x0001) (Edit)
	unsigned char                                      UnknownData03[0x7];                                       // 0x0CE9(0x0007) MISSED OFFSET
	struct FPhotonHideReplicationData                  HideReplicationData;                                      // 0x0CF0(0x0030) (Net)
	struct FPhotonDetachReplicationData                DetachReplicationData;                                    // 0x0D20(0x0030) (Net)
	struct FPhotonSlideReplicationData                 SlideReplicationData;                                     // 0x0D50(0x0028) (Net)
	float                                              FragmentsMaxHp;                                           // 0x0D78(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      EnableCheckedSupportedFloor : 1;                          // 0x0D7C(0x0001) (Edit)
	unsigned char                                      EnableSeverImpactPoint : 1;                               // 0x0D7C(0x0001) (Edit)
	unsigned char                                      UnknownData04[0x1D3];                                     // 0x0D7D(0x01D3) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PhotonBlast.PhotonDestructibleMeshComponent");
		return pStaticClass;
	}


	void SetupFragmentsMaxHp(float HP);
	void SetServerDamagedDelegate(const struct FScriptDelegate& InDelegate);
	void SetFracturedMesh(class UPhotonDestructibleMesh* InFracturedMesh, bool Force);
	void Server_OnComponentHitAction(class UPrimitiveComponent* HitComp, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, const struct FVector& NormalImpulse, const struct FHitResult& Hit);
	bool Server_DamageFragmentsByRadius(const struct FVector4& WorldImpactVelocityAndRotateStrength, const struct FVector4& WorldImpactPointAndSpreadStrength, float HP, float Radius, bool Attenuation);
	bool Server_DamageFragmentsByHp(TArray<int> FragmentsIndex, TArray<float> HP, const struct FVector4& WorldImpactPointAndSpreadStrength, const struct FVector4& WorldImpactVelocityAndRotateSpeed);
	void OnRep_SlideData();
	void OnRep_ImpactData();
	void OnRep_FragmentsState();
	bool IsFragmentCanDestroy(int FragmentItemIndex);
	bool IsFragmentCanBeDamaged(int FragmentItemIndex);
	class UPhotonDestructibleMesh* GetPhotonDestructibleMesh();
	bool GetFragmentTransform(int FragmentIndex, bool WorldSpace, struct FTransform* OutTransform);
	bool GetFragmentsWorldPosition(int FragmentIndex, struct FVector* FragmentPosition);
	bool GetFragmentsNotDamaged(bool IsReturnNotDestroyedFragments, TArray<int>* Fragments);
	bool GetFragmentsDamaged(TArray<int>* Fragments);
	bool GetFragmentsByRadius(const struct FVector& HitPoint, float Radius, int DamageType, TArray<int>* FragmentsIndex, TArray<float>* ImpactDistance);
	int GetFragmentItemCount();
	bool GetFragmentBounds(int FragmentIndex, bool WorldSpace, struct FBox* OutBox);
	class UPhotonFracturedMesh* GetFracturedMesh();
	bool ClientGetFragmentsNotDamaged(bool IsReturnNotDestroyedFragments, TArray<int>* Fragments);
	bool ClientGetFragmentsDamaged(TArray<int>* Fragments);
	void ClientDamageAndInitalFragments(TArray<int> DamagedFragmentItemIndex, TArray<int> InitialFragmentItemIndex);
};


// Class PhotonBlast.PhotonReplicationInstancedStaticMeshComponent
// 0x00E0 (0x0E10 - 0x0D30)
class UPhotonReplicationInstancedStaticMeshComponent : public UInstancedStaticMeshComponent
{
public:
	unsigned char                                      UnknownData00[0x58];                                      // 0x0D30(0x0058) MISSED OFFSET
	int                                                ClusterUniqueID;                                          // 0x0D88(0x0004) (Edit, ZeroConstructor, DisableEditOnTemplate, EditConst, IsPlainOldData)
	bool                                               bCanMove;                                                 // 0x0D8C(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	EAOIEntityType                                     AOIEntityType;                                            // 0x0D8D(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	EClusterEntityState                                AOIEntityState;                                           // 0x0D8E(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      ClusterReplicationOpen : 1;                               // 0x0D8F(0x0001) (Edit, BlueprintVisible)
	class UDestructionSubsystem*                       SubsystemPtr;                                             // 0x0D90(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0D98(0x0008) MISSED OFFSET
	struct FLuaNetSerialization                        LuaNetSerialization;                                      // 0x0DA0(0x0050) (Net)
	struct FString                                     LuaFilePath;                                              // 0x0DF0(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	unsigned char                                      UnknownData02[0x10];                                      // 0x0E00(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PhotonBlast.PhotonReplicationInstancedStaticMeshComponent");
		return pStaticClass;
	}


	void UnRegistLuaTick();
	void UnRegisterFromCluster();
	void SetMoveable(bool Value);
	void SetClusterUniqueID(int InClusterID);
	void SetClusterEntityState(EClusterEntityState EntityState);
	void RegistLuaTick(float TickInterval);
	void RegisterToCluster();
	void MarkPropDirty(int PropIndex);
};


// Class PhotonBlast.PhotonInstancedDestructibleMeshComponent
// 0x01D0 (0x0FE0 - 0x0E10)
class UPhotonInstancedDestructibleMeshComponent : public UPhotonReplicationInstancedStaticMeshComponent
{
public:
	unsigned char                                      EnableImpactDamage : 1;                                   // 0x0E10(0x0001) (Edit)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0E11(0x0003) MISSED OFFSET
	struct FPhotonDestructibleImpactParam              ImpactParam;                                              // 0x0E14(0x0008) (Edit)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0E1C(0x0004) MISSED OFFSET
	class UPhotonDestructibleMesh*                     PhotonDestructibleMesh;                                   // 0x0E20(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ECollisionEnabled>                FragmentsCollisionEnabled;                                // 0x0E28(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x7];                                       // 0x0E29(0x0007) MISSED OFFSET
	struct FName                                       FragmentsCollisionProfileName;                            // 0x0E30(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	TArray<struct FPhotonDestructibleFragmentStateData> HideInstanceReplicationData;                              // 0x0E38(0x0010) (Net, ZeroConstructor)
	TArray<struct FPhotonDestructibleImpactData>       DetachInstanceReplicationData;                            // 0x0E48(0x0010) (Net, ZeroConstructor)
	float                                              FragmentsMaxHp;                                           // 0x0E58(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      EnableCheckedSupportedFloor : 1;                          // 0x0E5C(0x0001) (Edit)
	unsigned char                                      EnableSeverImpactPoint : 1;                               // 0x0E5C(0x0001) (Edit)
	unsigned char                                      UnknownData03[0x183];                                     // 0x0E5D(0x0183) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PhotonBlast.PhotonInstancedDestructibleMeshComponent");
		return pStaticClass;
	}


	void SetupFragmentsMaxHp(float HP);
	void SetServerDamagedDelegate(const struct FScriptDelegate& InDelegate);
	void SetPhysMaterialOverride(class UPhysicalMaterial* NewPhysMaterial);
	void SetFracturedMesh(class UPhotonDestructibleMesh* InFracturedMesh, bool Force);
	void Server_OnComponentHitAction(class UPrimitiveComponent* HitComp, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, const struct FVector& NormalImpulse, const struct FHitResult& Hit);
	bool Server_DamageFragmentsByRadius(const struct FVector4& WorldImpactVelocity, const struct FVector4& WorldHitPointAndSpreadSpeed, float HP, float Radius, bool Attenuation);
	TArray<int> ReplaceAllInstances(TArray<struct FTransform> InstanceTransforms, bool bShouldReturnIndices);
	void OnRep_ImpactData();
	void OnRep_FragmentsState();
	bool IsFragmentCanDestroy(int InstanceIndex, int FragmentItemIndex);
	class UPhotonDestructibleMesh* GetPhotonDestructibleMesh();
	TArray<int> GetInstancesOverlappingSphere(const struct FVector& Center, float Radius, bool bSphereInWorldSpace);
	int GetInstanceItemCount();
	bool GetFragmentTransform(int InstanceIndex, int FragmentIndex, bool WorldSpace, struct FTransform* OutTransform);
	bool GetFragmentsWorldPosition(int InstanceIndex, int FragmentIndex, struct FVector* FragmentPosition);
	bool GetFragmentsNotDamaged(int InstanceIndex, bool IsReturnNotDestroyedFragments, TArray<int>* FragmentsNoDamaged);
	bool GetFragmentsDamaged(int InstanceIndex, TArray<int>* FragmentsDamaged);
	int GetFragmentItemCount();
	bool GetFragmentBounds(int InstanceIndex, int FragmentIndex, bool WorldSpace, struct FBox* OutBox);
	class UPhotonFracturedMesh* GetFracturedMesh();
	int AddInstanceWorldSpace(const struct FTransform& WorldTransform);
	TArray<int> AddInstances(TArray<struct FTransform> InstanceTransforms, bool bShouldReturnIndices, bool bMarkRenderStateDirty);
	int AddInstance(const struct FTransform& InstanceTransform);
};


// Class PhotonBlast.PhotonHierarchicalInstancedDestructibleMeshComponent
// 0x00E0 (0x10C0 - 0x0FE0)
class UPhotonHierarchicalInstancedDestructibleMeshComponent : public UPhotonInstancedDestructibleMeshComponent
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0FE0(0x0010) MISSED OFFSET
	TArray<int>                                        SortedInstances;                                          // 0x0FF0(0x0010) (ZeroConstructor)
	int                                                NumBuiltInstances;                                        // 0x1000(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x1004(0x0004) MISSED OFFSET
	struct FBox                                        BuiltInstanceBounds;                                      // 0x1008(0x001C) (IsPlainOldData)
	struct FBox                                        UnbuiltInstanceBounds;                                    // 0x1024(0x001C) (IsPlainOldData)
	TArray<struct FBox>                                UnbuiltInstanceBoundsList;                                // 0x1040(0x0010) (ZeroConstructor)
	TArray<int>                                        UnbuiltInstanceIndexList;                                 // 0x1050(0x0010) (ZeroConstructor)
	unsigned char                                      bEnableDensityScaling : 1;                                // 0x1060(0x0001)
	unsigned char                                      UnknownData02[0x27];                                      // 0x1061(0x0027) MISSED OFFSET
	int                                                OcclusionLayerNumNodes;                                   // 0x1088(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FBoxSphereBounds                            CacheMeshExtendedBounds;                                  // 0x108C(0x001C) (IsPlainOldData)
	unsigned char                                      UnknownData03[0x8];                                       // 0x10A8(0x0008) MISSED OFFSET
	int                                                MinInstancesToSplitNode;                                  // 0x10B0(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData04[0xC];                                       // 0x10B4(0x000C) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PhotonBlast.PhotonHierarchicalInstancedDestructibleMeshComponent");
		return pStaticClass;
	}


	bool ShowInstances(TArray<int> InstanceIndices, TArray<struct FTransform> InstanceTransforms);
	bool RemoveInstances(TArray<int> InstancesToRemove);
};


// Class PhotonBlast.PhotonDestructibleMeshActor
// 0x0010 (0x04C0 - 0x04B0)
class APhotonDestructibleMeshActor : public AActor
{
public:
	class UPhotonDestructibleMeshComponent*            PhotonDestructibleMeshComponent;                          // 0x04B0(0x0008) (Edit, BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, EditConst, InstancedReference, IsPlainOldData)
	unsigned char                                      DestructibleMeshActorReplication : 1;                     // 0x04B8(0x0001) (Edit, BlueprintVisible)
	unsigned char                                      UnknownData00[0x7];                                       // 0x04B9(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PhotonBlast.PhotonDestructibleMeshActor");
		return pStaticClass;
	}

};


// Class PhotonBlast.ClusterReplicationVolume
// 0x0050 (0x0530 - 0x04E0)
class AClusterReplicationVolume : public AVolume
{
public:
	bool                                               bForReplication;                                          // 0x04E0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bForClusterDivide;                                        // 0x04E1(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x04E2(0x0006) MISSED OFFSET
	struct FClusterAOIConfig                           ClusterConfig;                                            // 0x04E8(0x0038) (Edit, BlueprintVisible)
	struct FClusterReplicationProxy                    ClusterReplication;                                       // 0x0520(0x0010) (Net)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PhotonBlast.ClusterReplicationVolume");
		return pStaticClass;
	}

};


// Class PhotonBlast.ClusterReplicationSelectVolume
// 0x0008 (0x04E8 - 0x04E0)
class AClusterReplicationSelectVolume : public AVolume
{
public:
	int16_t                                            LevelGroup;                                               // 0x04E0(0x0002) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x04E2(0x0006) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PhotonBlast.ClusterReplicationSelectVolume");
		return pStaticClass;
	}

};


// Class PhotonBlast.MovieScenePhotonDestructibleSection
// 0x0230 (0x02E0 - 0x00B0)
class UMovieScenePhotonDestructibleSection : public UMovieSceneSection
{
public:
	struct FIntegralCurve                              PhotonDestructibleKeys;                                   // 0x00B0(0x0070)
	struct FRichCurve                                  TimeSpeedCurve;                                           // 0x0120(0x0070)
	struct FRichCurve                                  SpreadSpeedCurve;                                         // 0x0190(0x0070)
	struct FRichCurve                                  VelocitySpeedCurve;                                       // 0x0200(0x0070)
	struct FRichCurve                                  RotationSpeedCurve;                                       // 0x0270(0x0070)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PhotonBlast.MovieScenePhotonDestructibleSection");
		return pStaticClass;
	}

};


// Class PhotonBlast.MovieScenePhotonDestructibleTrack
// 0x0010 (0x0068 - 0x0058)
class UMovieScenePhotonDestructibleTrack : public UMovieSceneNameableTrack
{
public:
	TArray<class UMovieSceneSection*>                  PhotonDestructibleSections;                               // 0x0058(0x0010) (ExportObject, ZeroConstructor)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PhotonBlast.MovieScenePhotonDestructibleTrack");
		return pStaticClass;
	}

};


// Class PhotonBlast.PhotonDestructibleMesh
// 0x0180 (0x03F0 - 0x0270)
class UPhotonDestructibleMesh : public UStaticMesh
{
public:
	class UPhotonFracturedMesh*                        FracturedMesh;                                            // 0x0270(0x0008) (ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum EPhotonDestructibleAction>        DestructibleAction;                                       // 0x0278(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UseDefaultParameter : 1;                                  // 0x0279(0x0001) (Edit)
	TEnumAsByte<enum EPhotonCollisionType>             FragmentCollisonType;                                     // 0x027A(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x5];                                       // 0x027B(0x0005) MISSED OFFSET
	struct FPhotonDestructibleMeshPhysicsDetachData    PhysicsDetachData;                                        // 0x0280(0x00C0) (Edit)
	unsigned char                                      UnknownData01[0xB0];                                      // 0x0340(0x00B0) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PhotonBlast.PhotonDestructibleMesh");
		return pStaticClass;
	}

};


// Class PhotonBlast.DestructionSubsystem
// 0x0000 (0x05B8 - 0x05B8)
class UDestructionSubsystem : public UClusterReplicationSubsystem
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PhotonBlast.DestructionSubsystem");
		return pStaticClass;
	}

};


// Class PhotonBlast.PhotonFracturedMesh
// 0x00D8 (0x0100 - 0x0028)
class UPhotonFracturedMesh : public UObject
{
public:
	TArray<class UPhotonFracturedFragmentInfo*>        FracturedFragmentInfo;                                    // 0x0028(0x0010) (ZeroConstructor)
	TArray<int>                                        InsideMaterialIndex;                                      // 0x0038(0x0010) (Edit, ZeroConstructor)
	TMap<int, class UPhotonFracturedFragmentInfo*>     FragmentIndex2FragmentInfo;                               // 0x0048(0x0050) (ZeroConstructor)
	TMap<struct FName, class UPhotonFracturedFragmentInfo*> FragmentName2FragmentInfo;                                // 0x0098(0x0050) (ZeroConstructor)
	struct FSupportGraph                               SupportGraph;                                             // 0x00E8(0x0018)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PhotonBlast.PhotonFracturedMesh");
		return pStaticClass;
	}

};


// Class PhotonBlast.PhotonFracturedMeshSettings
// 0x0000 (0x0028 - 0x0028)
class UPhotonFracturedMeshSettings : public UObject
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PhotonBlast.PhotonFracturedMeshSettings");
		return pStaticClass;
	}

};


// Class PhotonBlast.PhotonFEdgeData
// 0x0000 (0x0028 - 0x0028)
class UPhotonFEdgeData : public UObject
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PhotonBlast.PhotonFEdgeData");
		return pStaticClass;
	}

};


// Class PhotonBlast.PhotonFracturedFragmentInfo
// 0x0048 (0x0070 - 0x0028)
class UPhotonFracturedFragmentInfo : public UObject
{
public:
	int                                                FragmentItemIndex;                                        // 0x0028(0x0004) (Edit, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              MassOverride;                                             // 0x002C(0x0004) (Edit, ZeroConstructor, EditConst, IsPlainOldData)
	struct FFragmentConvexElem                         ConvexElemForCollision;                                   // 0x0030(0x0010)
	struct FVector                                     centerPoint;                                              // 0x0040(0x000C) (IsPlainOldData)
	struct FBox                                        LocalBoundBox;                                            // 0x004C(0x001C) (IsPlainOldData)
	unsigned char                                      CanDestroy : 1;                                           // 0x0068(0x0001) (Edit)
	unsigned char                                      ConnectFloor : 1;                                         // 0x0068(0x0001) (Edit)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0069(0x0003) MISSED OFFSET
	int                                                ChunkIndex;                                               // 0x006C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PhotonBlast.PhotonFracturedFragmentInfo");
		return pStaticClass;
	}

};


// Class PhotonBlast.PhotonHierarchicalInstancedStaticMeshComponent
// 0x0110 (0x0F30 - 0x0E20)
class UPhotonHierarchicalInstancedStaticMeshComponent : public UHierarchicalInstancedStaticMeshComponent
{
public:
	class UStaticMesh*                                 EffectStaticMesh;                                         // 0x0E20(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	class USkeletalMesh*                               EffectSkeleMesh;                                          // 0x0E28(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	class UClass*                                      AnimClass;                                                // 0x0E30(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	class UClass*                                      EffectActorClass;                                         // 0x0E38(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	TArray<struct FPhotonInstanceImpactData>           InstanceImpactData;                                       // 0x0E40(0x0010) (Net, ZeroConstructor)
	float                                              InstanceMaxHp;                                            // 0x0E50(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum EEffectType>                      EffectType;                                               // 0x0E54(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0E55(0x0003) MISSED OFFSET
	float                                              EffectDurationTime;                                       // 0x0E58(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0E5C(0x0004) MISSED OFFSET
	struct FName                                       EffectCollisionProfileName;                               // 0x0E60(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      bCullEffect : 1;                                          // 0x0E68(0x0001) (Edit)
	unsigned char                                      UnknownData02[0x3];                                       // 0x0E69(0x0003) MISSED OFFSET
	float                                              CullDistance;                                             // 0x0E6C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      bUseExactVelocity : 1;                                    // 0x0E70(0x0001) (Edit)
	unsigned char                                      UnknownData03[0x3];                                       // 0x0E71(0x0003) MISSED OFFSET
	float                                              VelocityLength;                                           // 0x0E74(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              MinVelocityExplosion;                                     // 0x0E78(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              MaxVelocityExplosion;                                     // 0x0E7C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	class UAkAudioEvent*                               HitSound;                                                 // 0x0E80(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData04[0x50];                                      // 0x0E88(0x0050) UNKNOWN PROPERTY: SetProperty PhotonBlast.PhotonHierarchicalInstancedStaticMeshComponent.ExceptDamageTypes
	bool                                               bVehicleHitUseClientPreShow;                              // 0x0ED8(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData05[0x3];                                       // 0x0ED9(0x0003) MISSED OFFSET
	float                                              bVehicleHitScale;                                         // 0x0EDC(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bUpdateSurrendActorPosition;                              // 0x0EE0(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bForceNetUpdate;                                          // 0x0EE1(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData06[0x4E];                                      // 0x0EE2(0x004E) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PhotonBlast.PhotonHierarchicalInstancedStaticMeshComponent");
		return pStaticClass;
	}


	void UpdatePickupAndDeadBoxInRange(const struct FVector& Location);
	void SetFracturedMesh(class UPhotonDestructibleMesh* InPhotonDestructibleMesh);
	bool ServerGetInstanceIndexsNotDamaged(TArray<int>* InstancesNoDamaged);
	bool ServerGetInstanceIndexsDamaged(TArray<int>* InstancesDamaged);
	bool Server_InstanceByHp(TArray<int> InstancedIndex, TArray<float> DamagesHp, const struct FVector& WorldImpactVelocity, EDestructionDamageType DamageType);
	bool Server_InstanceAndWorldVelocityByHp(TArray<int> InstancedIndex, TArray<float> DamagesHp, const struct FVector& WorldImpactPoint, EDestructionDamageType DamageType, float Strength);
	bool Server_DamageFragmentsByRadius(const struct FVector& WorldImpactVelocity, const struct FVector& WorldHitPointAndSpreadSpeed, float HP, float Radius);
	void OnTriggerServerEvent__DelegateSignature(class ASTExtraVehicleBase* VehicleActor, class UPrimitiveComponent* HitComp, class UPhotonHierarchicalInstancedStaticMeshComponent* MeshComponent, const struct FVector& DesPos, int TriggerIndex);
	void OnTriggeredByComp(class AActor* OtherActor, class UPrimitiveComponent* OtherComp, const struct FTriggerEvent& TriggerEvent);
	void OnTriggerClientEvent__DelegateSignature(class ASTExtraVehicleBase* VehicleActor, class UPrimitiveComponent* HitComp, class UPhotonHierarchicalInstancedStaticMeshComponent* MeshComponent, const struct FVector& DesPos, int TriggerIndex);
	void OnRep_ImpactData();
	void OnLocalVehicleHit(TArray<int> InstanceIndex, const struct FVector4& WorldImpactPointAndSpreadSpeed, const struct FVector4& WorldImpactVelocityAndRotateSpeed);
	class UPhotonDestructibleMesh* GetPhotonDestructibleMesh();
	bool GetInstanceByRadius(const struct FVector& HitPoint, float Radius, EDestructionDamageType DamageType, TArray<int>* InstancedIndex);
	class UPhotonFracturedMesh* GetFracturedMesh();
	void GenerateEffectInstanceWorldSpace(TArray<int> InstanceIndex, TArray<struct FVector> WorldImpactVelocityAndRotateSpeed);
	void GenerateEffectInstanceLocalSpace(TArray<int> InstanceIndex, TArray<struct FVector> LocalImpactVelocityAndRotateSpeed);
	void ClientCorrectVehicleHit(TArray<int> InstanceIndex);
};


// Class PhotonBlast.PhotonParticleModuleTypeDataMesh
// 0x0098 (0x0180 - 0x00E8)
class UPhotonParticleModuleTypeDataMesh : public UParticleModuleTypeDataMesh
{
public:
	float                                              TriggerDelay;                                             // 0x00E8(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              ImpactSpreadStrength;                                     // 0x00EC(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              ImpactVelocityMagnitude;                                  // 0x00F0(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector                                     ImpactVelocityDirection;                                  // 0x00F4(0x000C) (Edit, IsPlainOldData)
	float                                              ImpactRotationStrength;                                   // 0x0100(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bOverrideDetachGravity;                                   // 0x0104(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0105(0x0003) MISSED OFFSET
	struct FVector                                     DetachGravity;                                            // 0x0108(0x000C) (Edit, IsPlainOldData)
	bool                                               bOverrideDetachTimeSpeed;                                 // 0x0114(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0115(0x0003) MISSED OFFSET
	float                                              DetachTimeSpeed;                                          // 0x0118(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x64];                                      // 0x011C(0x0064) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PhotonBlast.PhotonParticleModuleTypeDataMesh");
		return pStaticClass;
	}

};


// Class PhotonBlast.PhotonReplicationSkeletalMeshComponent
// 0x00E0 (0x1430 - 0x1350)
class UPhotonReplicationSkeletalMeshComponent : public USkeletalMeshComponent
{
public:
	unsigned char                                      UnknownData00[0x58];                                      // 0x1350(0x0058) MISSED OFFSET
	int                                                ClusterUniqueID;                                          // 0x13A8(0x0004) (Edit, ZeroConstructor, DisableEditOnTemplate, EditConst, IsPlainOldData)
	bool                                               bCanMove;                                                 // 0x13AC(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	EAOIEntityType                                     AOIEntityType;                                            // 0x13AD(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	EClusterEntityState                                AOIEntityState;                                           // 0x13AE(0x0001) (Edit, ZeroConstructor, DisableEditOnTemplate, EditConst, IsPlainOldData)
	unsigned char                                      ClusterReplicationOpen : 1;                               // 0x13AF(0x0001) (Edit, BlueprintVisible)
	class UDestructionSubsystem*                       SubsystemPtr;                                             // 0x13B0(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData01[0x8];                                       // 0x13B8(0x0008) MISSED OFFSET
	struct FLuaNetSerialization                        LuaNetSerialization;                                      // 0x13C0(0x0050) (Net)
	struct FString                                     LuaFilePath;                                              // 0x1410(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	unsigned char                                      UnknownData02[0x10];                                      // 0x1420(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PhotonBlast.PhotonReplicationSkeletalMeshComponent");
		return pStaticClass;
	}


	void UnRegistLuaTick();
	void UnRegisterFromCluster();
	void SetMoveable(bool Value);
	void SetClusterUniqueID(int InClusterID);
	void SetClusterEntityState(EClusterEntityState EntityState);
	void RegistLuaTick(float TickInterval);
	void RegisterToCluster();
	void MarkPropDirty(int PropIndex);
};


// Class PhotonBlast.PhotonStaticeMeshActor
// 0x0008 (0x0668 - 0x0660)
class APhotonStaticeMeshActor : public ADecoratorActor
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0660(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PhotonBlast.PhotonStaticeMeshActor");
		return pStaticClass;
	}

};


// Class PhotonBlast.ReusableStaticMeshActor
// 0x0010 (0x04D0 - 0x04C0)
class AReusableStaticMeshActor : public AStaticMeshActor
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x04C0(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PhotonBlast.ReusableStaticMeshActor");
		return pStaticClass;
	}


	void OnSpawn();
	void OnRecycle();
};


// Class PhotonBlast.ReusableSkeletalMeshActor
// 0x0010 (0x0548 - 0x0538)
class AReusableSkeletalMeshActor : public ASkeletalMeshActor
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0538(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PhotonBlast.ReusableSkeletalMeshActor");
		return pStaticClass;
	}


	void OnSpawn();
	void OnRecycle();
};


// Class PhotonBlast.ReusableDestructibleMeshActor
// 0x0010 (0x04D0 - 0x04C0)
class AReusableDestructibleMeshActor : public APhotonDestructibleMeshActor
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x04C0(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PhotonBlast.ReusableDestructibleMeshActor");
		return pStaticClass;
	}


	void OnSpawn();
	void OnRecycle();
};


// Class PhotonBlast.PhotonStaticMeshComponent
// 0x0030 (0x0C10 - 0x0BE0)
class UPhotonStaticMeshComponent : public UStaticMeshComponent
{
public:
	class UStaticMesh*                                 EffectStaticMesh;                                         // 0x0BE0(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              InstanceMaxHp;                                            // 0x0BE8(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum EEffectType>                      EffectType;                                               // 0x0BEC(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0BED(0x0003) MISSED OFFSET
	float                                              EffectDurationTime;                                       // 0x0BF0(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0BF4(0x0004) MISSED OFFSET
	struct FName                                       EffectCollisionProfileName;                               // 0x0BF8(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bVehicleHitUseClientPreShow;                              // 0x0C00(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x3];                                       // 0x0C01(0x0003) MISSED OFFSET
	float                                              bVehicleHitScale;                                         // 0x0C04(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x8];                                       // 0x0C08(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PhotonBlast.PhotonStaticMeshComponent");
		return pStaticClass;
	}


	void SetFracturedMesh(class UPhotonDestructibleMesh* InPhotonDestructibleMesh);
	class UPhotonDestructibleMesh* GetPhotonDestructibleMesh();
	class UPhotonFracturedMesh* GetFracturedMesh();
};


}

