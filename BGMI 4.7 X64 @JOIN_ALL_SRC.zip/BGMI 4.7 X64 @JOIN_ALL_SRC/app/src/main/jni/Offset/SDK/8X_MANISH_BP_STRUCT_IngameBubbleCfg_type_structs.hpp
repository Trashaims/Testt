#pragma once

// SDK GENERATE BY TELEGRAM ;- (@Manish8x) (4.7.0 -- 64Bit) DM TO BUY TOOL AVLABLE FOR SELL
// Telegram:- @Manish8x
// GEN ONWed Nov 18 07:25:11 2026
 
namespace SDK
{
//---------------------By Tg @Manish8x---------------------------
//Script Structs
//---------------------By Tg @Manish8x---------------------------

// UserDefinedStruct BP_STRUCT_IngameBubbleCfg_type.BP_STRUCT_IngameBubbleCfg_type
// 0x002C
struct FBP_STRUCT_IngameBubbleCfg_type
{
	int                                                BubbleSkillID_0_1809A6C0180DD79F38CF233A06FD9BB4;         // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                EmojiID_1_3ABD110029DD9B9431E894EC0F7F1414;               // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FString                                     PicturePath_2_44E1AB003F99151A6FB100C50559C908;           // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     BubbleEffectIcon_3_4EEA1940055C741F7735B2D1011D8CAE;      // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                BubbleEffectType_4_71A15F807B33FB4E77514747011CD295;      // 0x0028(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

